This sample demonstrates how to package a DataSet in a gzipped DIME attachment.


Web Services Enhancements (WSE) 1.0 SP1 for Microsoft .NET
http://microsoft.com/downloads/details.aspx?FamilyId=06255A94-2635-4D29-A90C-28B282993A41&displaylang=en